// ======================================================================
// theme-toggle.js — robust delegating switch for PaperMod variants
// Path: blog_src/assets/blog/js/theme-toggle.js
// ======================================================================

// Helper: set theme and persist
function __applyTheme(next) {
  var body = document.body;
  if (!body) return;
  if (next === 'dark') body.classList.add('dark');
  else body.classList.remove('dark');
  try {
    localStorage.setItem('pref-theme', next);
  } catch (_) {}
}

// Detect initial preference (does not override PaperMod early script)
(function () {
  // noop: rely on PaperMod anti-FOUC to set initial class instantly
})();

// 1) Direct binding after DOMContentLoaded (common case)
document.addEventListener('DOMContentLoaded', function () {
  var btn =
    document.querySelector('.theme-toggle') ||
    document.getElementById('theme-toggle') ||
    document.querySelector('[data-theme-toggle]') ||
    document.querySelector('button[title*="Toggle theme"]');
  if (btn) {
    btn.addEventListener('click', function (e) {
      // Some themes use <a>; do not navigate
      if (e && e.preventDefault) e.preventDefault();
      var isDark = document.body.classList.contains('dark');
      __applyTheme(isDark ? 'light' : 'dark');
    });
  }
});

// 2) Event delegation fallback: catches clicks even if header is re-rendered
document.addEventListener(
  'click',
  function (e) {
    var el =
      e.target.closest &&
      e.target.closest(
        '.theme-toggle, #theme-toggle, [data-theme-toggle], button[title*="Toggle theme"]'
      );
    if (!el) return;
    if (e && e.preventDefault) e.preventDefault();
    var isDark = document.body.classList.contains('dark');
    __applyTheme(isDark ? 'light' : 'dark');
  },
  true
);

// 3) Keyboard shortcut fallback (Alt+T like PaperMod hint)
document.addEventListener('keydown', function (e) {
  if (e.altKey && (e.key === 't' || e.key === 'T')) {
    e.preventDefault();
    var isDark = document.body.classList.contains('dark');
    __applyTheme(isDark ? 'light' : 'dark');
  }
});

// Debug ping to ensure the file is loaded
try {
  console.debug('theme-toggle.js: loaded (delegating mode)');
} catch (_) {}
